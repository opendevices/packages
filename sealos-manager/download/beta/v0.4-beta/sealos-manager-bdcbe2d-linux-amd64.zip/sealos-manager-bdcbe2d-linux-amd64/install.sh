#!/bin/sh

CONFIG_FILE="config.json"
PROD_CONFIG="${CONFIG_FILE}"

INIT=$(readlink -f /sbin/init)

if [[ !  $INIT =~ .*systemd.* ]]; then
        echo "Error: OS does not support systemd. Not supported"
        exit 1
fi

if [ -z $ARCH ]; then
        export ARCH=$(cat ./prod/goarch)
fi

touch install.logs
make install > install.logs 2>&1

if [ $? -eq 0 ]; then
        echo "Install: SealOS Manager successfully Installed"
else
        echo "Error: installing SealOS Manager failed; please check: install.logs"
        exit 1
fi

if [ -f $PROD_CONFIG ]; then
        cp -f /boot/${CONFIG_FILE} /boot/${COFIG_FILE}.backup
        cp -f $PROD_CONGIG /boot/
fi

if [ $? -eq 0 ]; then
        echo "Install: Successfully installed sealos manager and its files"
        exit 0
else
        echo "Error: Failed to installed sealos manager and its files"
        exit 1
fi
