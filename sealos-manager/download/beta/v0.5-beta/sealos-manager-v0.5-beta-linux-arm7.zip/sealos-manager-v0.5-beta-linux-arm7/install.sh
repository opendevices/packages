#!/bin/bash

MANAGER="sealos-manager"
JOURNAL="sealos-manager-journal"
ACTIONS="sealos-manager-actions"
ACTIONS_OFFLINE="sealos-manager-actions-offline"
BOOT_SETUP="sealos-boot-setup"

CONFIG_FILE="config.json"
PROD_CONFIG="${CONFIG_FILE}"
INIT=$(readlink -f /sbin/init)
PREFIX=/usr/lib/
UNITS_PREFIX=/etc/systemd/system/
MULTIUSER_TARGET_UNITS_INSTALL_PREFIX=/etc/systemd/system/multi-user.target.wants/
BASIC_TARGET_UNITS_INSTALL_PREFIX=/etc/systemd/system/basic.target.wants/
SHUTDOWN_PATH=/lib/systemd/system-shutdown/
USER_SHUTDOWN_PATH=/usr/lib/systemd/system-shutdown/


if [[ !  $INIT =~ .*systemd.* ]]; then
        echo "Error: OS does not support systemd. Not supported"
        exit 1
fi

if [ -z $GOARCH ]; then
        export GOARCH=$(cat ./prod/goarch)
fi

GOBIN=$(pwd)/build/${GOARCH}

echo "Installing $MANAGER"
	install -m 644 units/${MANAGER}.service ${DESTDIR}${UNITS_PREFIX}/${MANAGER}.service
	install -m 644 units/${JOURNAL}.service ${DESTDIR}${UNITS_PREFIX}/${JOURNAL}.service
	install -m 644 units/${ACTIONS}.service ${DESTDIR}${UNITS_PREFIX}/${ACTIONS}.service
	install -m 644 units/${ACTIONS_OFFLINE}.service ${DESTDIR}${UNITS_PREFIX}/${ACTIONS_OFFLINE}.service
	install -m 644 units/${BOOT_SETUP}.service ${DESTDIR}${UNITS_PREFIX}/${BOOT_SETUP}.service
	ln -s ${DESTDIR}${UNITS_PREFIX}/${MANAGER}.service \
		${DESTDIR}${MULTIUSER_TARGET_UNITS_INSTALL_PREFIX}/${MANAGER}.service
	ln -s ${DESTDIR}${UNITS_PREFIX}/${JOURNAL}.service \
		${DESTDIR}${MULTIUSER_TARGET_UNITS_INSTALL_PREFIX}/${JOURNAL}.service
	ln -s ${DESTDIR}${UNITS_PREFIX}/${ACTIONS}.service \
		${DESTDIR}${MULTIUSER_TARGET_UNITS_INSTALL_PREFIX}/${ACTIONS}.service
	mkdir -p ${DESTDIR}${BASIC_TARGET_UNITS_INSTALL_PREFIX}
	ln -s ${DESTDIR}${UNITS_PREFIX}/${BOOT_SETUP}.service \
		${DESTDIR}${BASIC_TARGET_UNITS_INSTALL_PREFIX}/${BOOT_SETUP}.service

	install -d ${DESTDIR}${PREFIX}/${MANAGER}
	install -m 755 ${GOBIN}/${MANAGER} ${DESTDIR}${PREFIX}/${MANAGER}/
	install -m 755 ${GOBIN}/${JOURNAL} ${DESTDIR}${PREFIX}/${MANAGER}/
	install -m 755 ${GOBIN}/${ACTIONS} ${DESTDIR}${PREFIX}/${MANAGER}/
	install -m 755 ${GOBIN}/${ACTIONS_OFFLINE} ${DESTDIR}/${SHUTDOWN_PATH}/ | true
	install -m 755 ${GOBIN}/${ACTIONS_OFFLINE} ${DESTDIR}/${USER_SHUTDOWN_PATH}/ | true
	install -m 755 ${GOBIN}/${BOOT_SETUP} ${DESTDIR}${PREFIX}/${MANAGER}/

        if [ $? -eq 0 ]; then
                echo "Install: SealOS Manager successfully Installed"
        else
                echo "Error: installing SealOS Manager failed; please check: install.logs"
                exit 1
        fi


echo "Installing $MANAGER Configuration"
        install -d ${DESTDIR}${PREFIX}/${MANAGER}/factory
        install -m 644 factory/config.json ${DESTDIR}${PREFIX}/${MANAGER}/factory/


        if [ -f /boot/${CONFIG_FILE} ]; then
                cp -f /boot/${CONFIG_FILE} ${DESTDIR}/boot/${CONFIG_FILE}.backup | true
        fi

        install -m 600 $PROD_CONFIG ${DESTDIR}/boot/ | true
        install -m 600 config.json ${DESTDIR}/boot/ | true


        if [ $? -eq 0 ]; then
                echo "Install: Successfully installed sealos manager and its files"
                exit 0
        else
                echo "Error: Failed to installed sealos manager and its files"
                exit 1
        fi
