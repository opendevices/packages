#!/bin/bash

# Uninstall from ${DESTDIR}

MANAGER="sealos-manager"
JOURNAL="sealos-manager-journal"
ACTIONS="sealos-manager-actions"
ACTIONS_OFFLINE="sealos-manager-actions-offline"
BOOT_SETUP="sealos-boot-setup"
DOWNLOAD_TOOL="sealos-download"

PREFIX=/usr/lib/
UNITS_WANTS_PREFIX=/usr/lib/

if [ ! -f "${DESTDIR}/${UNITS_WANTS_PREFIX}/systemd/system/emergency.target" ]; then
        echo "Uninstall: guessing that systemd units are in /lib/systemd/"
        UNITS_WANTS_PREFIX=/lib/
fi

# Setup the final UNITS_PREFIX and use it
UNITS_PREFIX=${UNITS_WANTS_PREFIX}/systemd/system/

MULTIUSER_TARGET_UNITS_INSTALL_PREFIX=${UNITS_PREFIX}/multi-user.target.wants/
SYSINIT_TARGET_UNITS_INSTALL_PREFIX=${UNITS_PREFIX}/sysinit.target.wants/

echo "Uninstalling $MANAGER"
        rm -fr ${DESTDIR}${PREFIX}/${MANAGER}

        rm -f ${DESTDIR}${MULTIUSER_TARGET_UNITS_INSTALL_PREFIX}/${MANAGER}.service | true
        rm -f ${DESTDIR}${MULTIUSER_TARGET_UNITS_INSTALL_PREFIX}/${JOURNAL}.service | true
        rm -f ${DESTDIR}${MULTIUSER_TARGET_UNITS_INSTALL_PREFIX}/${JOURNAL}.path | true
        rm -f ${DESTDIR}${MULTIUSER_TARGET_UNITS_INSTALL_PREFIX}/${ACTIONS}.service | true
        rm -f ${DESTDIR}${MULTIUSER_TARGET_UNITS_INSTALL_PREFIX}/${ACTIONS}.path | true
        rm -f ${DESTDIR}${SYSINIT_TARGET_UNITS_INSTALL_PREFIX}/${BOOT_SETUP}.service | true

        rm -f ${DESTDIR}${UNITS_PREFIX}/${MANAGER}.service | true
        rm -f ${DESTDIR}${UNITS_PREFIX}/${JOURNAL}.service | true
        rm -f ${DESTDIR}${UNITS_PREFIX}/${JOURNAL}.path | true
        rm -f ${DESTDIR}${UNITS_PREFIX}/${ACTIONS}.service | true
        rm -f ${DESTDIR}${UNITS_PREFIX}/${ACTIONS}.path | true
        rm -f ${DESTDIR}${UNITS_PREFIX}/${BOOT_SETUP}.service | true
        rm -f ${DESTDIR}${UNITS_PREFIX}/${DOWNLOAD_TOOL}.service | true

        rm -f ${DESTDIR}${PREFIX}/tmpfiles.d/${MANAGER}.conf

        if [ $? -eq 0 ]; then
                echo "Uninstall: Successfully uninstalled sealos manager and its files"
                exit 0
        else
                echo "Error: Failed to uninstalled sealos manager and its files"
                exit 1
        fi
