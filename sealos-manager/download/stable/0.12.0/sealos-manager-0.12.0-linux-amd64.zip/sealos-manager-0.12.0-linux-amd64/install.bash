#!/bin/bash

# Manager programs to Install

# main co-ordinator agent
MANAGER="sealos-manager"

# log and journal handler
JOURNAL="sealos-manager-journal"

# actions and operations handler
ACTIONS="sealos-manager-actions"

# offline status synchronizer
ACTIONS_OFFLINE="sealos-manager-actions-offline"

# Boot setup and synchronizer
BOOT_SETUP="sealos-boot-setup"

# Download tool for apps - runs under user sealos-download
DOWNLOAD_TOOL="sealos-download"

# Main tool to update sealos-manager
MANAGER_UPDATE_TOOL="sealos-manager-update"

# OS and Manager config if any - if not present ignored
CONFIG_FILE="config.json"

#
# OS and Manager config that can be included in package
# ignored if not present
#
PROD_CONFIG="./prod/${CONFIG_FILE}"

#
# Where to install the tmpfiles
#
TMPFILES_PREFIX=/usr/lib/tmpfiles.d/

# Path to search to see where units are installed
UNITS_WANTS_PREFIX=/lib/

# Final place that will be used to intall units
UNITS_PREFIX=""

declare RUNTIME_ARGS="$@"

# Is this an update of a previous installation if so we have to restart
# manager
declare RESTART_NEW_MANAGER="false"

# If it is an update of a previous installation then we have a lock
# state here
declare SEALOS_MANAGER_UPDATE_STATE="/run/sealos-manager/manager/sealos-manager-update.state"

# Installation lock files
declare LOCKFD=99
declare LOCKFILE="/run/sealos-manager/download/sealos-install.lock"

#
# After finishing installation lets clean lock files and restart
#
clean_status() {
        if [ "$RESTART_NEW_MANAGER" = "true" ]; then
                flock -u $LOCKFD
                flock -xn $LOCKFD
                rm -f $LOCKFILE

                # Make sure we always restart manager
                always_restart_new_manager
        fi
        echo "Exit"
}

#
# Initialize installation and register cleanup
#
init_status() {
        eval "exec $LOCKFD>\"$LOCKFILE\""
        trap clean_status EXIT
}

#
# Get install lock file
#
getlock() { flock -xn $LOCKFD; }

#
# On sealos-manager update only
# Stop old manager if necessary
#
prepare_installation() {
        if [ "$INSTALL_MODE" != "UPDATE" ]; then
                return
        fi

        if [ -z "$DESTDIR" ]; then
                RESTART_NEW_MANAGER="true"
                init_status
                getlock
                if [ $? -ne 0 ]; then
                        echo "Error: Failed to aquire ${LOCKFILE}, another instance is running"
                        exit 1
                fi

                # If update actions does not exist create it
                if [ ! -f $SEALOS_MANAGER_UPDATE_STATE ]; then
                        echo -n "0" > $SEALOS_MANAGER_UPDATE_STATE
                fi

                echo "install: stopping Old SealOS Manager, please wait."

                # Lets first stop main manager
                systemctl stop sealos-manager || true
                # allow old manager to remotly report its state
                sleep 10
        fi
}

always_restart_new_manager() {
        if [ "$MANAGER_ALREADY_STARTED" = "true" ]; then
                # Nothing todo already performed
                return
        fi

        echo "install: starting New SealOS Manager, please wait."
        systemctl daemon-reload
        sleep 5
        systemctl start sealos-boot-setup
        systemctl start sealos-manager || true

        MANAGER_ALREADY_STARTED="true"
}

#
# On sealos-manager update only
# Start up New manager if necessary
#
finalize_installation() {
        if [ "$RESTART_NEW_MANAGER" = "true" ]; then
                if [ "$MANAGER_ALREADY_STARTED" = "true" ]; then
                        # Nothing todo already performed
                        return
                fi

                always_restart_new_manager
        else
                # Create first boot file
                if [ "$INSTALL_MODE" != "UPDATE" ]; then
                        # create first boot file
                        touch ${SEALOS_MANAGER_DIR}/first-boot
                fi
                echo "install: finishing without restarting new $MANAGER"
        fi
}

# Install manager tools
install_manager() {
        echo "install: installing $MANAGER units and programs"

        # Create configuration directory
        install -d ${DESTDIR}/data/system/etc/

        # Create var directory
        install -d ${DESTDIR}/data/system/var/

        # Create sealos manager installation directory
        install -d ${SEALOS_MANAGER_DIR}/A/usr/lib/
        install -d ${SEALOS_MANAGER_DIR}/B/usr/lib/

        if [ ! \( -e "${SEALOS_MANAGER_DIR}/.###current" \) ]; then
                olddir=$(pwd)
                cd ${SEALOS_MANAGER_DIR}
                ln -sr "./A" "./.###current" || true
                cd $olddir
        fi

        # Create extract Host OS directory
        install -d ${DESTDIR}/data/ionoid/extract/

        # Create download Host OS directory
        install -d ${DESTDIR}/data/ionoid/download/

        # copy unit files
        install -m 644 units/${MANAGER}.service \
                ${DESTDIR}${UNITS_PREFIX}/${MANAGER}.service \
                || true
        install -m 644 units/${JOURNAL}.service \
                ${DESTDIR}${UNITS_PREFIX}/${JOURNAL}.service \
                || true
        install -m 644 units/${JOURNAL}.path \
                ${DESTDIR}${UNITS_PREFIX}/${JOURNAL}.path \
                || true
        install -m 644 units/${ACTIONS}.service \
                ${DESTDIR}${UNITS_PREFIX}/${ACTIONS}.service \
                || true
        install -m 644 units/${ACTIONS}.path \
                ${DESTDIR}${UNITS_PREFIX}/${ACTIONS}.path \
                || true
        install -m 644 units/${BOOT_SETUP}.service \
                ${DESTDIR}${UNITS_PREFIX}/${BOOT_SETUP}.service \
                || true
        install -m 644 units/${DOWNLOAD_TOOL}.service \
                ${DESTDIR}${UNITS_PREFIX}/${DOWNLOAD_TOOL}.service || true
        install -m 644 units/${MANAGER_UPDATE_TOOL}.service \
                ${DESTDIR}${UNITS_PREFIX}/${MANAGER_UPDATE_TOOL}.service || true

        install -m 644 units/sealos-fs-mounter.service \
                ${DESTDIR}${UNITS_PREFIX}/ || true

        install -m 644 units/sealos-clean-files.service \
                ${DESTDIR}${UNITS_PREFIX}/ || true

        install -m 644 units/sealos-clean-files.timer \
                ${DESTDIR}${UNITS_PREFIX}/ || true

        install -m 644 units/sealos-apply-local.service \
                ${DESTDIR}${UNITS_PREFIX}/ || true
        install -m 644 units/sealos-apply-local.timer \
                ${DESTDIR}${UNITS_PREFIX}/ || true

        #
        # manually run symlinks and link units to their appropriate
        # target level, we do this cause the other way to install
        # units is to run "systemctl install unit" on an already running
        # system, which is not always the case for us, so better have
        # one consistent way where we track it in one place too
        #
        olddir=$(pwd)

        cd ${DESTDIR}${MULTIUSER_TARGET_UNITS_INSTALL_PREFIX}/
        ln -sr ../${MANAGER}.service ${MANAGER}.service > /dev/null 2>&1
        ln -sr ../${JOURNAL}.path ${JOURNAL}.path > /dev/null 2>&1
        ln -sr ../${ACTIONS}.path ${ACTIONS}.path > /dev/null 2>&1
        ln -sr ../${BOOT_SETUP}.service ${BOOT_SETUP}.service > /dev/null 2>&1

        cd $olddir

        cd ${DESTDIR}${SYSINIT_TARGET_UNITS_INSTALL_PREFIX}/
        ln -sr ../sealos-fs-mounter.service sealos-fs-mounter.service > /dev/null 2>&1

        cd $olddir
        cd ${DESTDIR}${TIMERS_TARGET_UNITS_INSTALL_PREFIX}/
        ln -sr ../sealos-clean-files.timer sealos-clean-files.timer > /dev/null 2>&1
        ln -sr ../sealos-apply-local.timer sealos-apply-local.timer > /dev/null 2>&1

        cd $olddir

        # finally install binaries and programs
        INSTALL_DIR="${SEALOS_MANAGER_DIR}/.###current/usr/lib/"
        install -m 755 ${GOBIN}/${MANAGER} ${INSTALL_DIR}/
        install -m 755 ${GOBIN}/${JOURNAL} ${INSTALL_DIR}/
        install -m 755 ${GOBIN}/${ACTIONS} ${INSTALL_DIR}/
        install -m 755 ${GOBIN}/${ACTIONS_OFFLINE} ${INSTALL_DIR}/
        install -m 755 ${GOBIN}/${BOOT_SETUP} ${INSTALL_DIR}/
        install -m 755 ${GOBIN}/${DOWNLOAD_TOOL} ${INSTALL_DIR}/
        install -m 755 ${GOBIN}/${MANAGER_UPDATE_TOOL}.bash \
                ${INSTALL_DIR}/ || true
        install -m 755 ${GOBIN}/sealos-fs-mounter.bash \
                ${INSTALL_DIR}/ || true
        install -m 755 ${GOBIN}/sealos-apply-local.bash \
                ${INSTALL_DIR}/ || true

        # Copy release machine
        if [ -f prod/machine ]; then
                install -m 644 prod/machine ${INSTALL_DIR}/
        fi

        if [ $? -ne 0 ]; then
                echo "Error: installing SealOS Manager failed; please check: install.logs"
                exit 1
        fi

        sleep 5
}


# Install manager configuration files
install_manager_files() {
        echo "install: installing $MANAGER configuration files"

        # install tmpfiles configurations
        install -m 644 tmpfiles.d/sealos-manager.conf ${DESTDIR}${TMPFILES_PREFIX}

        mkdir -p ${DESTDIR}/data/ionoid/boot/

        if [ -f ${DESTDIR}/data/ionoid/boot/config.json ]; then
                cp -f ${DESTDIR}/data/ionoid/boot/config.json \
                        ${DESTDIR}/data/ionoid/boot/config.json.backup || true
                chmod 600 ${DESTDIR}/data/ionoid/boot/config.json || true
                chmod 600 ${DESTDIR}/data/ionoid/boot/config.json.backup || true
        fi

        if [ -f ${PROD_CONFIG} ]; then
                install -m 600 ${PROD_CONFIG} ${DESTDIR}/data/ionoid/boot/config.json || true
        fi

        if [ $? -eq 0 ]; then
                echo "Install: Successfully installed sealos manager and its files"
        else
                echo "Install: Error: Failed to installed sealos manager and its files"
                exit 1
        fi
}


main() {
        echo "Install: installing ionoid-tools and $MANAGER, only systemd aware distros are supported"

        #
        # Some distros use /usr/lib/systemd/ to install units
        # others are still with old /lib where it is not merged with
        # /usr/lib/ , we start with /lib/ then switch back to /usr/lib/
        # if it is not a symlink to /lib
        #
        echo "install: trying ${DESTDIR}/${UNITS_WANTS_PREFIX}/ for installing system units"
        if [ ! -f "${DESTDIR}/${UNITS_WANTS_PREFIX}/systemd/system/emergency.target" ]; then
                UNITS_WANTS_PREFIX=/usr/lib/
                echo "install: trying ${DESTDIR}/${UNITS_WANTS_PREFIX}/ for installing system units"
        fi

        if [ ! -f "${DESTDIR}/${UNITS_WANTS_PREFIX}/systemd/system/emergency.target" ]; then
                echo "Install: Error: failed can not locate systemd installation units"
                exit 1
        fi

        #
        # Setup the final UNITS_PREFIX and use it
        #
        UNITS_PREFIX=${UNITS_WANTS_PREFIX}/systemd/system/
        MULTIUSER_TARGET_UNITS_INSTALL_PREFIX=${UNITS_PREFIX}/multi-user.target.wants/
        SYSINIT_TARGET_UNITS_INSTALL_PREFIX=${UNITS_PREFIX}/sysinit.target.wants/
        TIMERS_TARGET_UNITS_INSTALL_PREFIX=${UNITS_PREFIX}/timers.target.wants/

        # Setup goarch that was used to built the install
        if [ -z $GOARCH ]; then
                export GOARCH=$(cat ./prod/goarch)
        fi

        GOBIN=$(pwd)/build/${GOARCH}

        # Save current pwd
        OLD=$(pwd)

        SEALOS_MANAGER_DIR=${DESTDIR}/data/ionoid/${MANAGER}
        install -d ${SEALOS_MANAGER_DIR}

        # Stop old manager and setup files if necessary
        prepare_installation

        # Install manager tools 
        install_manager

        # Install other manager configuration files
        install_manager_files

        # Start again manager if necessary
        # Setup more files if needed
        finalize_installation

        exit 0
}

main $RUNTIME_ARGS
