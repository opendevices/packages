#!/bin/bash

# Uninstall from ${DESTDIR}

MANAGER="sealos-manager"
JOURNAL="sealos-manager-journal"
ACTIONS="sealos-manager-actions"
ACTIONS_OFFLINE="sealos-manager-actions-offline"
BOOT_SETUP="sealos-boot-setup"
DOWNLOAD_TOOL="sealos-download"
MANAGER_UPDATE_TOOL="sealos-manager-update"
SEALOS_CLEAN_FILES="sealos-clean-files"
SEALOS_APPLY_LOCAL="sealos-apply-local"

TMPFILES_PREFIX=/usr/lib/tmpfiles.d/
UNITS_WANTS_PREFIX=/lib/

if [ ! -f "${DESTDIR}/${UNITS_WANTS_PREFIX}/systemd/system/emergency.target" ]; then
        echo "Uninstall: guessing that systemd units are in /lib/systemd/"
        UNITS_WANTS_PREFIX=/usr/lib/
fi

# Setup the final UNITS_PREFIX and use it
UNITS_PREFIX=${UNITS_WANTS_PREFIX}/systemd/system/

MULTIUSER_TARGET_UNITS_INSTALL_PREFIX=${UNITS_PREFIX}/multi-user.target.wants/
SYSINIT_TARGET_UNITS_INSTALL_PREFIX=${UNITS_PREFIX}/sysinit.target.wants/
TIMERS_TARGET_UNITS_INSTALL_PREFIX=${UNITS_PREFIX}/timers.target.wants/
BASIC_TARGET_UNITS_INSTALL_PREFIX=${UNITS_PREFIX}/basic.target.wants/

SEALOS_MANAGER_DIR=${DESTDIR}/data/ionoid/${MANAGER}

echo "Uninstalling $MANAGER"

# Remove all tools
rm -fr ${DESTDIR}${PREFIX}/${MANAGER}
rm -fr ${SEALOS_MANAGER_DIR}

rm -f ${DESTDIR}${MULTIUSER_TARGET_UNITS_INSTALL_PREFIX}/${MANAGER}.service || true
rm -f ${DESTDIR}${MULTIUSER_TARGET_UNITS_INSTALL_PREFIX}/${JOURNAL}.service || true
rm -f ${DESTDIR}${MULTIUSER_TARGET_UNITS_INSTALL_PREFIX}/${JOURNAL}.path || true
rm -f ${DESTDIR}${MULTIUSER_TARGET_UNITS_INSTALL_PREFIX}/${ACTIONS}.service || true
rm -f ${DESTDIR}${MULTIUSER_TARGET_UNITS_INSTALL_PREFIX}/${ACTIONS}.path || true
rm -f ${DESTDIR}${MULTIUSER_TARGET_UNITS_INSTALL_PREFIX}/${BOOT_SETUP}.service || true

rm -f ${DESTDIR}${SYSINIT_TARGET_UNITS_INSTALL_PREFIX}/sealos-fs-mounter.service || true

rm -f ${DESTDIR}${TIMERS_TARGET_UNITS_INSTALL_PREFIX}/${SEALOS_CLEAN_FILES}.service || true
rm -f ${DESTDIR}${TIMERS_TARGET_UNITS_INSTALL_PREFIX}/${SEALOS_CLEAN_FILES}.timer || true
rm -f ${DESTDIR}${TIMERS_TARGET_UNITS_INSTALL_PREFIX}/${SEALOS_APPLY_LOCAL}.service || true
rm -f ${DESTDIR}${TIMERS_TARGET_UNITS_INSTALL_PREFIX}/${SEALOS_APPLY_LOCAL}.timer || true


# for old targets/services
rm -f ${DESTDIR}${SYSINIT_TARGET_UNITS_INSTALL_PREFIX}/${BOOT_SETUP}.service || true
rm -f ${DESTDIR}${BASIC_TARGET_UNITS_INSTALL_PREFIX}/${BOOT_SETUP}.service || true


rm -f ${DESTDIR}${UNITS_PREFIX}/${MANAGER}.service || true
rm -f ${DESTDIR}${UNITS_PREFIX}/${JOURNAL}.service || true
rm -f ${DESTDIR}${UNITS_PREFIX}/${JOURNAL}.path || true
rm -f ${DESTDIR}${UNITS_PREFIX}/${ACTIONS}.service || true
rm -f ${DESTDIR}${UNITS_PREFIX}/${ACTIONS}.path || true
rm -f ${DESTDIR}${UNITS_PREFIX}/${BOOT_SETUP}.service || true
rm -f ${DESTDIR}${UNITS_PREFIX}/${DOWNLOAD_TOOL}.service || true
rm -f ${DESTDIR}${UNITS_PREFIX}/${MANAGER_UPDATE_TOOL}.service || true
rm -f ${DESTDIR}${UNITS_PREFIX}/sealos-fs-mounter.service || true
rm -f ${DESTDIR}${UNITS_PREFIX}/${SEALOS_CLEAN_FILES}.service || true
rm -f ${DESTDIR}${UNITS_PREFIX}/${SEALOS_CLEAN_FILES}.timer || true
rm -f ${DESTDIR}${UNITS_PREFIX}/${SEALOS_APPLY_LOCAL}.service || true
rm -f ${DESTDIR}${UNITS_PREFIX}/${SEALOS_APPLY_LOCAL}.timer || true

rm -f ${DESTDIR}${TMPFILES_PREFIX}/${MANAGER}.conf

if [ $? -eq 0 ]; then
        echo "Uninstall: Successfully uninstalled sealos manager and its files"
        exit 0
else
        echo "Error: Failed to uninstalled sealos manager and its files"
        exit 1
fi
