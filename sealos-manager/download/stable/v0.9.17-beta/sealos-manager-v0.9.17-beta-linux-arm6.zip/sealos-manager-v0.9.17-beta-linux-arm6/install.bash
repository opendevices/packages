#!/bin/bash


# Tools to Install
MANAGER="sealos-manager"
JOURNAL="sealos-manager-journal"
ACTIONS="sealos-manager-actions"
ACTIONS_OFFLINE="sealos-manager-actions-offline"
BOOT_SETUP="sealos-boot-setup"
DOWNLOAD_TOOL="sealos-download"
MANAGER_UPDATE_TOOL="sealos-manager-update"


# Source config if any
CONFIG_FILE="config.json"

# Source config included in package if any
PROD_CONFIG="./prod/${CONFIG_FILE}"

# Check if this is a systemd supported OS
INIT=$(readlink -f ${DESTDIR}/sbin/init)

# Where to install
PREFIX=/usr/lib/
UNITS_WANTS_PREFIX=/usr/lib/

declare RUNTIME_ARGS="$@"

# Is this an update of a previous installation if so we have to restart
# manager
declare RESTART_NEW_MANAGER="false"

# If it is an update of a previous installation then we have a lock
# state here
declare SEALOS_MANAGER_UPDATE_STATE="/run/sealos-manager/manager/sealos-manager-update.state"

# Installation lock files
declare LOCKFD=99
declare LOCKFILE="/run/sealos-manager/download/sealos-install.lock"


# Get lock file
getlock() { flock -xn $LOCKFD; }


# After finishing installation lets clean our lock files and restart
# manager
clean_status() {
        if [ "$RESTART_NEW_MANAGER" = "true" ]; then
                flock -u $LOCKFD
                flock -xn $LOCKFD
                rm -f $LOCKFILE

                # Make sure we always restart manager
                restart_new_manager
        fi
        echo "Exit"
}

# Initialize installation and register hoos
init_status() {
        eval "exec $LOCKFD>\"$LOCKFILE\""
        trap clean_status EXIT
}

# Stop Old manager only if we are:
# not installing into $DESTDIR and it is an update
stop_old_manager() {
        if [ "$INSTALL_MODE" = "UPDATE" ] && [ -z "$DESTDIR" ]; then
                RESTART_NEW_MANAGER="true"
                init_status
                getlock
                if [ $? -ne 0 ]; then
                        echo "Error: Failed to aquire ${LOCKFILE}, another instance is running"
                        exit 1
                fi

                # If update actions does not exist create it
                if [ ! -f $SEALOS_MANAGER_UPDATE_STATE ]; then
                        echo -n "0" > $SEALOS_MANAGER_UPDATE_STATE
                fi

                echo "Stopping Old SealOS Manager, please wait."

                # Lets first stop main manager
                systemctl stop sealos-manager || true
                # allow old manager to remotly report its state
                sleep 10
        fi
}

# Start up New manager if necessary
restart_new_manager() {
        if [ "$MANAGER_ALREADY_STARTED" = "true" ]; then
                # Nothing todo already performed
                return
        fi

        if [ "$RESTART_NEW_MANAGER" = "true" ]; then
                MANAGER_ALREADY_STARTED="true"

                echo "Starting New SealOS Manager, please wait."
                systemctl daemon-reload
                sleep 5
                systemctl start sealos-manager || true
        else
                echo "Finishing without Starting New SealOS Manager"
        fi
}

# Install manager tools
install_manager() {
        echo "Installing $MANAGER"
        install -m 644 units/${MANAGER}.service \
                ${DESTDIR}${UNITS_PREFIX}/${MANAGER}.service \
                || true
        install -m 644 units/${JOURNAL}.service \
                ${DESTDIR}${UNITS_PREFIX}/${JOURNAL}.service \
                || true
        install -m 644 units/${JOURNAL}.path \
                ${DESTDIR}${UNITS_PREFIX}/${JOURNAL}.path \
                || true
        install -m 644 units/${ACTIONS}.service \
                ${DESTDIR}${UNITS_PREFIX}/${ACTIONS}.service \
                || true
        install -m 644 units/${ACTIONS}.path \
                ${DESTDIR}${UNITS_PREFIX}/${ACTIONS}.path \
                || true
        install -m 644 units/${BOOT_SETUP}.service \
                ${DESTDIR}${UNITS_PREFIX}/${BOOT_SETUP}.service \
                || true
        install -m 644 units/${DOWNLOAD_TOOL}.service \
                ${DESTDIR}${UNITS_PREFIX}/${DOWNLOAD_TOOL}.service || true
        install -m 644 units/${MANAGER_UPDATE_TOOL}.service \
                ${DESTDIR}${UNITS_PREFIX}/${MANAGER_UPDATE_TOOL}.service || true

        ln -s ${DESTDIR}${UNITS_PREFIX}/${MANAGER}.service \
                ${DESTDIR}${MULTIUSER_TARGET_UNITS_INSTALL_PREFIX}/${MANAGER}.service \
                || true
        ln -s ${DESTDIR}${UNITS_PREFIX}/${JOURNAL}.path \
                ${DESTDIR}${MULTIUSER_TARGET_UNITS_INSTALL_PREFIX}/${JOURNAL}.path \
                || true
        ln -s ${DESTDIR}${UNITS_PREFIX}/${ACTIONS}.path \
                ${DESTDIR}${MULTIUSER_TARGET_UNITS_INSTALL_PREFIX}/${ACTIONS}.path \
                || true

        ln -s ${DESTDIR}${UNITS_PREFIX}/${BOOT_SETUP}.service \
                ${DESTDIR}${MULTIUSER_TARGET_UNITS_INSTALL_PREFIX}/${BOOT_SETUP}.service \
                || true

        install -d ${DESTDIR}${PREFIX}/${MANAGER}
        install -m 755 ${GOBIN}/${MANAGER} ${DESTDIR}${PREFIX}/${MANAGER}/
        install -m 755 ${GOBIN}/${JOURNAL} ${DESTDIR}${PREFIX}/${MANAGER}/
        install -m 755 ${GOBIN}/${ACTIONS} ${DESTDIR}${PREFIX}/${MANAGER}/
        install -m 755 ${GOBIN}/${ACTIONS_OFFLINE} ${DESTDIR}${PREFIX}/${MANAGER}/
        install -m 755 ${GOBIN}/${BOOT_SETUP} ${DESTDIR}${PREFIX}/${MANAGER}/
        install -m 755 ${GOBIN}/${DOWNLOAD_TOOL} ${DESTDIR}${PREFIX}/${MANAGER}/
        install -m 755 ${GOBIN}/${MANAGER_UPDATE_TOOL}.bash \
                ${DESTDIR}${PREFIX}/${MANAGER}/ || true

        if [ $? -eq 0 ]; then
                echo "Install: SealOS Manager successfully Installed"
        else
                echo "Error: installing SealOS Manager failed; please check: install.logs"
                exit 1
        fi

        sleep 5
}


# Install manager configuration files
install_manager_files() {
        echo "Installing $MANAGER Configuration"

        install -m 644 tmpfiles.d/sealos-manager.conf ${DESTDIR}${PREFIX}/tmpfiles.d/

        # Copy release machine
        if [ -f prod/machine ]; then
                install -m 755 prod/machine ${DESTDIR}${PREFIX}/${MANAGER}/
        fi

        mkdir -p ${DESTDIR}/data/ionoid/boot/

        if [ -f ${DESTDIR}/data/ionoid/boot/config.json ]; then
                cp -f ${DESTDIR}/data/ionoid/boot/config.json \
                        ${DESTDIR}/data/ionoid/boot/config.json.backup || true
                chmod 600 ${DESTDIR}/data/ionoid/boot/config.json || true
                chmod 600 ${DESTDIR}/data/ionoid/boot/config.json.backup || true
        fi

        if [ -f ${PROD_CONFIG} ]; then
                install -m 600 ${PROD_CONFIG} ${DESTDIR}/data/ionoid/boot/config.json || true
        fi

        if [ $? -eq 0 ]; then
                echo "Install: Successfully installed sealos manager and its files"
                exit 0
        else
                echo "Error: Failed to installed sealos manager and its files"
                exit 1
        fi
}


main() {
        if [ ! -f "${DESTDIR}/${UNITS_WANTS_PREFIX}/systemd/system/emergency.target" ]; then
                echo "Using ${DESTDIR}/lib/ for Installing system units"
                UNITS_WANTS_PREFIX=/lib/
        fi

        if [ ! -f "${DESTDIR}/${UNITS_WANTS_PREFIX}/systemd/system/emergency.target" ]; then
                echo "Installation failed: can not locate systemd installation units"
                exit 1
        fi

        # Setup the final UNITS_PREFIX and use it
        UNITS_PREFIX=${UNITS_WANTS_PREFIX}/systemd/system/

        MULTIUSER_TARGET_UNITS_INSTALL_PREFIX=${UNITS_PREFIX}/multi-user.target.wants/

        if [[ !  $INIT =~ .*systemd.* ]]; then
                echo "Error: OS does not support systemd. Not supported"
                exit 1
        fi

        if [ -z $GOARCH ]; then
                export GOARCH=$(cat ./prod/goarch)
        fi

        GOBIN=$(pwd)/build/${GOARCH}
        OLD=$(pwd)

        # Stop old manager if necessary
        stop_old_manager

        # Install manager tools 
        install_manager

        # Install other manager configuration files
        install_manager_files

        # Start again manager if necessary 
        restart_new_manager

        exit 0
}

main $RUNTIME_ARGS
